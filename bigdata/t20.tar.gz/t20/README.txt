This is the README.txt for a zip archive from http://cricsheet.org/
You can always find the most up-to-date version of this zip file at:
  http://cricsheet.org/downloads/t20s.zip

The data files contained in this zip file are version 0.6 files. You can
learn about the latest format at http://cricsheet.org/format/

The data files contained in this zip archive are listed below. The first
field is the start date of the match (for test matches or other multi-day
matches), or the actual date (for all other types of match). The second is
the type of match, either IPL, Test, ODI, ODM, T20, IT20 or MDM. The 3rd
field is the id of the data file, and the remainder of the line shows the
teams involved in the match.

2005-02-17 - T20  - 211048 - New Zealand vs Australia
2005-06-13 - T20  - 211028 - England vs Australia
2005-10-21 - T20  - 222678 - South Africa vs New Zealand
2006-01-09 - T20  - 226374 - Australia vs South Africa
2006-02-16 - T20  - 237242 - New Zealand vs West Indies
2006-02-24 - T20  - 238195 - South Africa vs Australia
2006-06-15 - T20  - 225271 - England vs Sri Lanka
2006-08-28 - T20  - 225263 - England vs Pakistan
2006-12-01 - T20  - 255954 - South Africa vs India
2006-12-22 - T20  - 251487 - New Zealand vs Sri Lanka
2006-12-26 - T20  - 251488 - New Zealand vs Sri Lanka
2007-01-09 - T20  - 249227 - Australia vs England
2007-06-28 - T20  - 258463 - England vs West Indies
2007-06-29 - T20  - 258464 - England vs West Indies
2007-09-01 - T20  - 306987 - Kenya vs Bangladesh
2007-09-02 - T20  - 306989 - Bangladesh vs Pakistan
2007-09-04 - T20  - 306991 - Kenya vs Pakistan
2007-09-11 - T20  - 287853 - South Africa vs West Indies
2007-09-12 - T20  - 287854 - Kenya vs New Zealand
2007-09-12 - T20  - 287855 - Pakistan vs Scotland
2007-09-12 - T20  - 287856 - Australia vs Zimbabwe
2007-09-13 - T20  - 287857 - Bangladesh vs West Indies
2007-09-13 - T20  - 287858 - England vs Zimbabwe
2007-09-14 - T20  - 287860 - Kenya vs Sri Lanka
2007-09-14 - T20  - 287861 - Australia vs England
2007-09-14 - T20  - 287862 - India vs Pakistan
2007-09-15 - T20  - 287863 - New Zealand vs Sri Lanka
2007-09-15 - T20  - 287864 - South Africa vs Bangladesh
2007-09-16 - T20  - 287865 - India vs New Zealand
2007-09-16 - T20  - 287866 - Australia vs Bangladesh
2007-09-16 - T20  - 287867 - South Africa vs England
2007-09-17 - T20  - 287868 - Pakistan vs Sri Lanka
2007-09-18 - T20  - 287869 - England vs New Zealand
2007-09-18 - T20  - 287870 - Australia vs Pakistan
2007-09-18 - T20  - 287871 - Bangladesh vs Sri Lanka
2007-09-19 - T20  - 287872 - South Africa vs New Zealand
2007-09-19 - T20  - 287873 - England vs India
2007-09-20 - T20  - 287874 - Australia vs Sri Lanka
2007-09-20 - T20  - 287875 - Bangladesh vs Pakistan
2007-09-20 - T20  - 287876 - South Africa vs India
2007-09-22 - T20  - 287877 - New Zealand vs Pakistan
2007-09-22 - T20  - 287878 - Australia vs India
2007-09-24 - T20  - 287879 - India vs Pakistan
2007-10-20 - T20  - 297800 - India vs Australia
2007-11-23 - T20  - 298795 - South Africa vs New Zealand
2007-12-11 - T20  - 291343 - Australia vs New Zealand
2007-12-16 - T20  - 319112 - South Africa vs West Indies
2008-01-18 - T20  - 298804 - South Africa vs West Indies
2008-02-01 - T20  - 291356 - Australia vs India
2008-02-05 - T20  - 300435 - New Zealand vs England
2008-02-07 - T20  - 300436 - New Zealand vs England
2008-04-20 - T20  - 343764 - Pakistan vs Bangladesh
2008-06-13 - T20  - 296903 - England vs New Zealand
2008-06-20 - T20  - 319142 - West Indies vs Australia
2008-08-03 - T20  - 354456 - Bermuda vs Scotland
2008-08-04 - T20  - 361530 - Ireland vs Kenya
2008-08-04 - T20  - 361531 - Netherlands vs Scotland
2008-10-11 - T20  - 361656 - Pakistan vs Sri Lanka
2008-10-13 - T20  - 361660 - Pakistan vs Sri Lanka
2008-11-05 - T20  - 350347 - South Africa vs Bangladesh
2008-12-26 - T20  - 366707 - New Zealand vs West Indies
2008-12-28 - T20  - 366708 - New Zealand vs West Indies
2009-01-11 - T20  - 351694 - Australia vs South Africa
2009-01-13 - T20  - 351695 - Australia vs South Africa
2009-02-10 - T20  - 386535 - Sri Lanka vs India
2009-02-15 - T20  - 351696 - Australia vs New Zealand
2009-02-25 - T20  - 386494 - New Zealand vs India
2009-02-27 - T20  - 366622 - New Zealand vs India
2009-03-15 - T20  - 352674 - West Indies vs England
2009-03-27 - T20  - 350475 - South Africa vs Australia
2009-03-29 - T20  - 350476 - South Africa vs Australia
2009-05-07 - T20  - 392615 - Australia vs Pakistan
2009-06-05 - T20  - 355991 - England vs Netherlands
2009-06-06 - T20  - 355992 - New Zealand vs Scotland
2009-06-06 - T20  - 355993 - Australia vs West Indies
2009-06-06 - T20  - 355994 - Bangladesh vs India
2009-06-07 - T20  - 355995 - Scotland vs South Africa
2009-06-07 - T20  - 355996 - England vs Pakistan
2009-06-08 - T20  - 355997 - Bangladesh vs Ireland
2009-06-08 - T20  - 355998 - Australia vs Sri Lanka
2009-06-09 - T20  - 355999 - Netherlands vs Pakistan
2009-06-09 - T20  - 356000 - New Zealand vs South Africa
2009-06-10 - T20  - 356001 - India vs Ireland
2009-06-10 - T20  - 356002 - Sri Lanka vs West Indies
2009-06-11 - T20  - 356003 - Ireland vs New Zealand
2009-06-11 - T20  - 356004 - England vs South Africa
2009-06-12 - T20  - 356005 - Pakistan vs Sri Lanka
2009-06-12 - T20  - 356006 - India vs West Indies
2009-06-13 - T20  - 356007 - South Africa vs West Indies
2009-06-13 - T20  - 356008 - New Zealand vs Pakistan
2009-06-14 - T20  - 356009 - Ireland vs Sri Lanka
2009-06-14 - T20  - 356010 - England vs India
2009-06-15 - T20  - 356011 - England vs West Indies
2009-06-15 - T20  - 356012 - Ireland vs Pakistan
2009-06-16 - T20  - 356013 - New Zealand vs Sri Lanka
2009-06-16 - T20  - 356014 - India vs South Africa
2009-06-18 - T20  - 356015 - Pakistan vs South Africa
2009-06-19 - T20  - 356016 - Sri Lanka vs West Indies
2009-06-21 - T20  - 356017 - Pakistan vs Sri Lanka
2009-08-02 - T20  - 401076 - West Indies vs Bangladesh
2009-08-12 - T20  - 403375 - Sri Lanka vs Pakistan
2009-08-30 - T20  - 350050 - England vs Australia
2009-09-02 - T20  - 403385 - Sri Lanka vs New Zealand
2009-09-04 - T20  - 403386 - Sri Lanka vs New Zealand
2009-11-12 - T20  - 426723 - New Zealand vs Pakistan
2009-11-13 - T20  - 387563 - South Africa vs England
2009-11-13 - T20  - 426724 - New Zealand vs Pakistan
2009-11-15 - T20  - 387564 - South Africa vs England
2009-12-09 - T20  - 430884 - India vs Sri Lanka
2009-12-12 - T20  - 430885 - India vs Sri Lanka
2010-02-03 - T20  - 423782 - New Zealand vs Bangladesh
2010-02-05 - T20  - 406207 - Australia vs Pakistan
2010-02-09 - T20  - 439495 - Afghanistan vs Ireland
2010-02-09 - T20  - 439497 - Canada vs Netherlands
2010-02-10 - T20  - 439499 - Canada vs Kenya
2010-02-11 - T20  - 439505 - Ireland vs Scotland
2010-02-12 - T20  - 439507 - Afghanistan vs Netherlands
2010-02-13 - T20  - 439510 - Ireland vs Netherlands
2010-02-13 - T20  - 439511 - Afghanistan vs Ireland
2010-02-19 - T20  - 440945 - England vs Pakistan
2010-02-20 - T20  - 440946 - England vs Pakistan
2010-02-21 - T20  - 406197 - Australia vs West Indies
2010-02-23 - T20  - 406198 - Australia vs West Indies
2010-02-26 - T20  - 423787 - New Zealand vs Australia
2010-02-28 - T20  - 423788 - New Zealand vs Australia
2010-02-28 - T20  - 439139 - West Indies vs Zimbabwe
2010-04-30 - T20  - 412677 - West Indies vs Ireland
2010-04-30 - T20  - 412678 - New Zealand vs Sri Lanka
2010-05-01 - T20  - 412679 - Afghanistan vs India
2010-05-01 - T20  - 412680 - Bangladesh vs Pakistan
2010-05-02 - T20  - 412682 - India vs South Africa
2010-05-02 - T20  - 412683 - Australia vs Pakistan
2010-05-03 - T20  - 412685 - West Indies vs England
2010-05-03 - T20  - 412686 - Sri Lanka vs Zimbabwe
2010-05-04 - T20  - 412681 - England vs Ireland
2010-05-04 - T20  - 412684 - New Zealand vs Zimbabwe
2010-05-05 - T20  - 412687 - Afghanistan vs South Africa
2010-05-05 - T20  - 412688 - Australia vs Bangladesh
2010-05-06 - T20  - 412689 - England vs Pakistan
2010-05-06 - T20  - 412690 - New Zealand vs South Africa
2010-05-07 - T20  - 412691 - Australia vs India
2010-05-07 - T20  - 412692 - West Indies vs Sri Lanka
2010-05-08 - T20  - 412693 - New Zealand vs Pakistan
2010-05-08 - T20  - 412694 - England vs South Africa
2010-05-09 - T20  - 412695 - West Indies vs India
2010-05-09 - T20  - 412696 - Australia vs Sri Lanka
2010-05-10 - T20  - 412697 - Pakistan vs South Africa
2010-05-10 - T20  - 412698 - England vs New Zealand
2010-05-11 - T20  - 412699 - India vs Sri Lanka
2010-05-11 - T20  - 412700 - West Indies vs Australia
2010-05-13 - T20  - 412701 - England vs Sri Lanka
2010-05-14 - T20  - 412702 - Australia vs Pakistan
2010-05-16 - T20  - 412703 - Australia vs England
2010-05-19 - T20  - 439146 - West Indies vs South Africa
2010-05-20 - T20  - 447539 - West Indies vs South Africa
2010-05-22 - T20  - 456991 - New Zealand vs Sri Lanka
2010-05-23 - T20  - 456992 - New Zealand vs Sri Lanka
2010-06-12 - T20  - 452153 - Zimbabwe vs India
2010-06-13 - T20  - 452154 - Zimbabwe vs India
2010-07-05 - T20  - 426392 - Australia vs Pakistan
2010-07-06 - T20  - 426393 - Australia vs Pakistan
2010-09-05 - T20  - 426417 - England vs Pakistan
2010-09-07 - T20  - 426418 - England vs Pakistan
2010-10-08 - T20  - 463141 - South Africa vs Zimbabwe
2010-10-10 - T20  - 463142 - South Africa vs Zimbabwe
2010-10-26 - T20  - 478279 - Pakistan vs South Africa
2010-10-27 - T20  - 461565 - Pakistan vs South Africa
2010-10-31 - T20  - 446956 - Australia vs Sri Lanka
2010-12-26 - T20  - 473918 - New Zealand vs Pakistan
2010-12-28 - T20  - 473919 - New Zealand vs Pakistan
2010-12-30 - T20  - 473920 - New Zealand vs Pakistan
2011-01-09 - T20  - 463149 - South Africa vs India
2011-01-12 - T20  - 446960 - Australia vs England
2011-01-14 - T20  - 446961 - Australia vs England
2011-04-21 - T20  - 489212 - West Indies vs Pakistan
2011-06-04 - T20  - 489220 - West Indies vs India
2011-06-25 - T20  - 474466 - England vs Sri Lanka
2011-08-06 - T20  - 516204 - Sri Lanka vs Australia
2011-08-08 - T20  - 516205 - Sri Lanka vs Australia
2011-08-31 - T20  - 474476 - England vs India
2011-09-16 - T20  - 523735 - Zimbabwe vs Pakistan
2011-09-18 - T20  - 523736 - Zimbabwe vs Pakistan
2011-09-23 - T20  - 525816 - England vs West Indies
2011-09-25 - T20  - 525817 - England vs West Indies
2011-10-11 - T20  - 531982 - Bangladesh vs West Indies
2011-10-13 - T20  - 514023 - South Africa vs Australia
2011-10-15 - T20  - 527012 - Zimbabwe vs New Zealand
2011-10-16 - T20  - 514024 - South Africa vs Australia
2011-10-17 - T20  - 527013 - Zimbabwe vs New Zealand
2011-10-29 - T20  - 521217 - India vs England
2011-11-25 - T20  - 530432 - Pakistan vs Sri Lanka
2011-11-29 - T20  - 538068 - Bangladesh vs Pakistan
2012-02-01 - T20  - 518954 - Australia vs India
2012-02-03 - T20  - 518955 - Australia vs India
2012-02-11 - T20  - 520595 - New Zealand vs Zimbabwe
2012-02-14 - T20  - 520596 - New Zealand vs Zimbabwe
2012-02-17 - T20  - 520597 - New Zealand vs South Africa
2012-02-19 - T20  - 520598 - New Zealand vs South Africa
2012-02-22 - T20  - 520599 - New Zealand vs South Africa
2012-02-22 - T20  - 543883 - Kenya vs Ireland
2012-02-23 - T20  - 531635 - England vs Pakistan
2012-02-23 - T20  - 543884 - Kenya vs Ireland
2012-02-24 - T20  - 543885 - Kenya vs Ireland
2012-02-25 - T20  - 531636 - England vs Pakistan
2012-02-27 - T20  - 531637 - England vs Pakistan
2012-03-13 - T20  - 546410 - Canada vs Netherlands
2012-03-14 - T20  - 546414 - Ireland vs Kenya
2012-03-14 - T20  - 546418 - Afghanistan vs Netherlands
2012-03-18 - T20  - 546442 - Ireland vs Scotland
2012-03-18 - T20  - 546443 - Afghanistan vs Canada
2012-03-22 - T20  - 546462 - Canada vs Ireland
2012-03-23 - T20  - 546470 - Ireland vs Netherlands
2012-03-23 - T20  - 546473 - Canada vs Scotland
2012-03-24 - T20  - 546477 - Afghanistan vs Ireland
2012-03-27 - T20  - 540173 - West Indies vs Australia
2012-03-30 - T20  - 540174 - West Indies vs Australia
2012-03-30 - T20  - 556252 - South Africa vs India
2012-06-01 - T20  - 562437 - Sri Lanka vs Pakistan
2012-06-03 - T20  - 562438 - Sri Lanka vs Pakistan
2012-06-24 - T20  - 534208 - England vs West Indies
2012-06-30 - T20  - 560921 - New Zealand vs West Indies
2012-07-01 - T20  - 560922 - New Zealand vs West Indies
2012-07-18 - T20  - 567071 - Ireland vs Bangladesh
2012-07-25 - T20  - 567205 - Netherlands vs Bangladesh
2012-07-26 - T20  - 573672 - Netherlands vs Bangladesh
2012-08-07 - T20  - 564786 - Sri Lanka vs India
2012-09-05 - T20  - 571148 - Australia vs Pakistan
2012-09-07 - T20  - 571149 - Australia vs Pakistan
2012-09-08 - T20  - 534233 - England vs South Africa
2012-09-10 - T20  - 534234 - England vs South Africa
2012-09-10 - T20  - 571150 - Australia vs Pakistan
2012-09-11 - T20  - 565820 - India vs New Zealand
2012-09-12 - T20  - 534235 - England vs South Africa
2012-09-18 - T20  - 533272 - Sri Lanka vs Zimbabwe
2012-09-19 - T20  - 533273 - Australia vs Ireland
2012-09-19 - T20  - 533274 - Afghanistan vs India
2012-09-20 - T20  - 533275 - South Africa vs Zimbabwe
2012-09-21 - T20  - 533276 - Bangladesh vs New Zealand
2012-09-21 - T20  - 533277 - Afghanistan vs England
2012-09-22 - T20  - 533278 - Sri Lanka vs South Africa
2012-09-22 - T20  - 533279 - Australia vs West Indies
2012-09-23 - T20  - 533280 - New Zealand vs Pakistan
2012-09-23 - T20  - 533281 - England vs India
2012-09-24 - T20  - 533282 - Ireland vs West Indies
2012-09-25 - T20  - 533283 - Bangladesh vs Pakistan
2012-09-27 - T20  - 533284 - Sri Lanka vs New Zealand
2012-09-27 - T20  - 533285 - England vs West Indies
2012-09-28 - T20  - 533286 - Pakistan vs South Africa
2012-09-28 - T20  - 533287 - Australia vs India
2012-09-29 - T20  - 533288 - England vs New Zealand
2012-09-29 - T20  - 533289 - Sri Lanka vs West Indies
2012-09-30 - T20  - 533290 - Australia vs South Africa
2012-09-30 - T20  - 533291 - India vs Pakistan
2012-10-01 - T20  - 533292 - New Zealand vs West Indies
2012-10-01 - T20  - 533293 - Sri Lanka vs England
2012-10-02 - T20  - 533294 - Australia vs Pakistan
2012-10-02 - T20  - 533295 - India vs South Africa
2012-10-04 - T20  - 533296 - Sri Lanka vs Pakistan
2012-10-05 - T20  - 533297 - Australia vs West Indies
2012-10-07 - T20  - 533298 - Sri Lanka vs West Indies
2012-10-30 - T20  - 582186 - Sri Lanka vs New Zealand
2012-12-10 - T20  - 587476 - Bangladesh vs West Indies
2012-12-20 - T20  - 565810 - India vs England
2012-12-21 - T20  - 567353 - South Africa vs New Zealand
2012-12-22 - T20  - 565811 - India vs England
2012-12-23 - T20  - 567354 - South Africa vs New Zealand
2012-12-25 - T20  - 589306 - India vs Pakistan
2012-12-26 - T20  - 567355 - South Africa vs New Zealand
2012-12-28 - T20  - 589307 - India vs Pakistan
2013-01-26 - T20  - 573019 - Australia vs Sri Lanka
2013-01-28 - T20  - 573020 - Australia vs Sri Lanka
2013-02-09 - T20  - 569237 - New Zealand vs England
2013-02-12 - T20  - 569238 - New Zealand vs England
2013-02-13 - T20  - 573027 - Australia vs West Indies
2013-02-15 - T20  - 569239 - New Zealand vs England
2013-03-02 - T20  - 593986 - West Indies vs Zimbabwe
2013-03-03 - T20  - 567367 - South Africa vs Pakistan
2013-03-03 - T20  - 592272 - Afghanistan vs Scotland
2013-03-03 - T20  - 593987 - West Indies vs Zimbabwe
2013-03-04 - T20  - 592273 - Afghanistan vs Scotland
2013-03-15 - T20  - 592268 - Canada vs Kenya
2013-03-16 - T20  - 592269 - Canada vs Kenya
2013-03-31 - T20  - 602477 - Sri Lanka vs Bangladesh
2013-04-19 - T20  - 630951 - Kenya vs Netherlands
2013-04-20 - T20  - 592276 - Kenya vs Netherlands
2013-05-11 - T20  - 623571 - Zimbabwe vs Bangladesh
2013-05-12 - T20  - 623572 - Zimbabwe vs Bangladesh
2013-06-25 - T20  - 566926 - England vs New Zealand
2013-06-27 - T20  - 566927 - England vs New Zealand
2013-07-27 - T20  - 645645 - West Indies vs Pakistan
2013-07-28 - T20  - 645647 - West Indies vs Pakistan
2013-08-02 - T20  - 635658 - Sri Lanka vs South Africa
2013-08-04 - T20  - 635659 - Sri Lanka vs South Africa
2013-08-06 - T20  - 635660 - Sri Lanka vs South Africa
2013-08-23 - T20  - 659545 - Zimbabwe vs Pakistan
2013-08-24 - T20  - 659547 - Zimbabwe vs Pakistan
2013-08-29 - T20  - 566937 - England vs Australia
2013-08-31 - T20  - 566938 - England vs Australia
2013-09-30 - T20  - 662383 - Afghanistan vs Kenya
2013-10-10 - T20  - 647247 - India vs Australia
2013-10-11 - T20  - 662387 - Afghanistan vs Kenya
2013-11-06 - T20  - 668959 - Bangladesh vs New Zealand
2013-11-13 - T20  - 649101 - Pakistan vs South Africa
2013-11-15 - T20  - 649103 - Pakistan vs South Africa
2013-11-15 - T20  - 660107 - Afghanistan vs Netherlands
2013-11-16 - T20  - 660113 - Canada vs Ireland
2013-11-16 - T20  - 660123 - Afghanistan vs Scotland
2013-11-19 - T20  - 660149 - Kenya vs Scotland
2013-11-20 - T20  - 685727 - South Africa vs Pakistan
2013-11-21 - T20  - 668969 - Sri Lanka vs New Zealand
2013-11-22 - T20  - 660173 - Netherlands vs Scotland
2013-11-22 - T20  - 685729 - South Africa vs Pakistan
2013-11-23 - T20  - 660185 - Kenya vs Netherlands
2013-11-24 - T20  - 660203 - Afghanistan vs Kenya
2013-11-26 - T20  - 660209 - Canada vs Kenya
2013-11-28 - T20  - 660223 - Netherlands vs Scotland
2013-11-30 - T20  - 660235 - Afghanistan vs Ireland
2013-12-08 - T20  - 657631 - Afghanistan vs Pakistan
2013-12-11 - T20  - 657633 - Pakistan vs Sri Lanka
2013-12-13 - T20  - 657635 - Pakistan vs Sri Lanka
2014-01-11 - T20  - 661695 - New Zealand vs West Indies
2014-01-15 - T20  - 661697 - New Zealand vs West Indies
2014-01-29 - T20  - 636164 - Australia vs England
2014-01-31 - T20  - 636165 - Australia vs England
2014-02-02 - T20  - 636166 - Australia vs England
2014-02-12 - T20  - 690351 - Bangladesh vs Sri Lanka
2014-02-14 - T20  - 690353 - Bangladesh vs Sri Lanka
2014-02-19 - T20  - 702141 - West Indies vs Ireland
2014-02-21 - T20  - 702143 - West Indies vs Ireland
2014-03-09 - T20  - 636536 - West Indies vs England
2014-03-11 - T20  - 636537 - West Indies vs England
2014-03-12 - T20  - 648681 - South Africa vs Australia
2014-03-13 - T20  - 636538 - West Indies vs England
2014-03-14 - T20  - 648683 - South Africa vs Australia
2014-03-16 - T20  - 682897 - Bangladesh vs Afghanistan
2014-03-16 - T20  - 682899 - Hong Kong vs Nepal
2014-03-17 - T20  - 682901 - Ireland vs Zimbabwe
2014-03-17 - T20  - 682903 - Netherlands vs United Arab Emirates
2014-03-18 - T20  - 682905 - Afghanistan vs Hong Kong
2014-03-18 - T20  - 682907 - Bangladesh vs Nepal
2014-03-19 - T20  - 682909 - Netherlands vs Zimbabwe
2014-03-19 - T20  - 682911 - Ireland vs United Arab Emirates
2014-03-20 - T20  - 682913 - Afghanistan vs Nepal
2014-03-20 - T20  - 682915 - Bangladesh vs Hong Kong
2014-03-21 - T20  - 682917 - United Arab Emirates vs Zimbabwe
2014-03-21 - T20  - 682919 - Ireland vs Netherlands
2014-03-21 - T20  - 682921 - India vs Pakistan
2014-03-22 - T20  - 682923 - South Africa vs Sri Lanka
2014-03-22 - T20  - 682925 - England vs New Zealand
2014-03-23 - T20  - 682927 - Australia vs Pakistan
2014-03-23 - T20  - 682929 - India vs West Indies
2014-03-24 - T20  - 682931 - New Zealand vs South Africa
2014-03-24 - T20  - 682933 - Netherlands vs Sri Lanka
2014-03-25 - T20  - 682935 - Bangladesh vs West Indies
2014-03-27 - T20  - 682937 - Netherlands vs South Africa
2014-03-27 - T20  - 682939 - England vs Sri Lanka
2014-03-28 - T20  - 682941 - Australia vs West Indies
2014-03-28 - T20  - 682943 - Bangladesh vs India
2014-03-29 - T20  - 682945 - Netherlands vs New Zealand
2014-03-29 - T20  - 682947 - England vs South Africa
2014-03-30 - T20  - 682949 - Bangladesh vs Pakistan
2014-03-30 - T20  - 682951 - Australia vs India
2014-03-31 - T20  - 682953 - England vs Netherlands
2014-03-31 - T20  - 682955 - New Zealand vs Sri Lanka
2014-04-01 - T20  - 682957 - Bangladesh vs Australia
2014-04-01 - T20  - 682959 - Pakistan vs West Indies
2014-04-03 - T20  - 682961 - Sri Lanka vs West Indies
2014-04-04 - T20  - 682963 - India vs South Africa
2014-04-06 - T20  - 682965 - India vs Sri Lanka
2014-05-20 - T20  - 667887 - England vs Sri Lanka
2014-07-05 - T20  - 730283 - West Indies vs New Zealand
2014-07-06 - T20  - 730285 - West Indies vs New Zealand
2014-08-27 - T20  - 730293 - West Indies vs Bangladesh
2014-09-07 - T20  - 667731 - England vs India
2014-10-05 - T20  - 727917 - Australia vs Pakistan
2014-11-05 - T20  - 754717 - Australia vs South Africa
2014-11-07 - T20  - 754719 - Australia vs South Africa
2014-11-09 - T20  - 754721 - Australia vs South Africa
2014-11-24 - T20  - 802327 - Hong Kong vs Nepal
2014-12-04 - T20  - 742617 - New Zealand vs Pakistan
2014-12-05 - T20  - 754039 - New Zealand vs Pakistan
2015-01-09 - T20  - 722335 - South Africa vs West Indies
2015-01-11 - T20  - 722337 - South Africa vs West Indies
2015-01-14 - T20  - 736063 - South Africa vs West Indies
2015-04-24 - T20  - 858491 - Bangladesh vs Pakistan
2015-05-22 - T20  - 868723 - Pakistan vs Zimbabwe
2015-05-24 - T20  - 868725 - Pakistan vs Zimbabwe
2015-06-20 - T20  - 889463 - Ireland vs Scotland
2015-06-23 - T20  - 743953 - England vs New Zealand
2015-07-01 - T20  - 883343 - Netherlands vs Nepal
2015-07-02 - T20  - 883345 - Netherlands vs Nepal
2015-07-05 - T20  - 817203 - Bangladesh vs South Africa
2015-07-07 - T20  - 817205 - Bangladesh vs South Africa
2015-07-09 - T20  - 875457 - Scotland vs United Arab Emirates
2015-07-09 - T20  - 875459 - Afghanistan vs Netherlands
2015-07-10 - T20  - 875461 - Ireland vs Namibia
2015-07-10 - T20  - 875463 - Canada vs Kenya
2015-07-10 - T20  - 875465 - Nepal vs United States of America
2015-07-10 - T20  - 875467 - Afghanistan vs United Arab Emirates
2015-07-11 - T20  - 875471 - Scotland vs Netherlands
2015-07-11 - T20  - 875473 - Kenya vs Oman
2015-07-12 - T20  - 875481 - Netherlands vs United Arab Emirates
2015-07-12 - T20  - 875485 - Scotland vs Afghanistan
2015-07-13 - T20  - 875491 - Nepal vs Ireland
2015-07-15 - T20  - 875501 - Ireland vs Papua New Guinea
2015-07-15 - T20  - 875507 - Hong Kong vs Nepal
2015-07-17 - T20  - 875513 - Nepal vs Papua New Guinea
2015-07-17 - T20  - 875521 - Ireland vs Hong Kong
2015-07-17 - T20  - 885969 - Zimbabwe vs India
2015-07-19 - T20  - 885971 - Zimbabwe vs India
2015-07-21 - T20  - 875541 - Afghanistan vs Hong Kong
2015-07-23 - T20  - 875545 - Afghanistan vs Papua New Guinea
2015-07-25 - T20  - 875549 - Hong Kong vs Scotland
2015-07-25 - T20  - 875551 - Afghanistan vs Oman
2015-07-25 - T20  - 875553 - Ireland vs Netherlands
2015-07-30 - T20  - 860279 - Sri Lanka vs Pakistan
2015-08-01 - T20  - 860281 - Sri Lanka vs Pakistan
2015-08-09 - T20  - 894293 - Zimbabwe vs New Zealand
2015-08-14 - T20  - 848839 - South Africa vs New Zealand
2015-08-16 - T20  - 848841 - South Africa vs New Zealand
2015-08-31 - T20  - 743975 - England vs Australia